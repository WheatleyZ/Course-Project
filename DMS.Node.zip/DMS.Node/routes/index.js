var express = require( 'express' );
var router = express.Router();
var session = require( 'express-session' );
var sql = require( 'mysql' );
var connection = sql.createConnection( {
  host: 'localhost',
  user: 'dms',
  password: '1234',
  database: 'dormitory'
} );
connection.connect();
router.use( session( {
  secret: '2015211911',
  cookie: {}
} ) );

router.get( '/login', function ( req, res, next ) {
  if ( req.session.userID ) {
    res.redirect( '/' );
  }
  res.render( 'index', {
    title: "宿舍管理系统",
    login: true
  } );
} )

router.get( '/logout', function ( req, res, next ) {
  req.session.destroy( ( err ) => { if ( err ) console.log( err ) } );
  res.redirect( '/' );
} )

router.post( '/login', function ( req, res, next ) {
  console.log( req.body );
  if ( req.body.username == "admin" && req.body.password == "admin" ) {
    console.log( "legit" );
    req.session.userID = "manager";
    req.session.save( ( err ) => { if ( err ) console.log( err ) } );
  }
} );

router.get( '/', function ( req, res, next ) {
  let roomquery = "SELECT roomID,dormitoryinfor.dormitoryID,dormitoryadmininfor.name \
                    FROM dormitory.roominfor,dormitory.dormitoryinfor,dormitory.dormitoryadmininfor \
                    WHERE roominfor.dormitoryID=dormitoryinfor.dormitoryID \
                    AND dormitoryinfor.dormitoryAdminID=dormitoryadmininfor.dormitoryAdminID"
  let studentquery = "SELECT studentinfor.studentID,studentinfor.name,studentinfor.gender,roominfor.roomID \
                    FROM dormitory.studentinfor,dormitory.roominfor \
                    WHERE (\
                        roominfor.bedAstuID=studentinfor.studentID \
                        OR roominfor.bedBstuID=studentinfor.studentID \
                        OR roominfor.bedCstuID=studentinfor.studentID \
                        OR roominfor.bedDstuID=studentinfor.studentID\
                      ) \
                      AND roominfor.roomID = "
  let loginstate = ( req.session.userID == "manager" )
  var renderdata = {
    title: "宿舍管理系统",
    logged: loginstate,
    room: []
  }
  function roomselection ( x ) {
    return new Promise( resolve => {
      connection.query( roomquery, function ( error, results, fields ) {
        results.forEach( room => {
          var roomdetail = {
            roomno: room.roomID,
            dorm: room.dormitoryID,
            admin: room.name,
            student: []
          }
          function studentselection ( y ) {
            return new Promise( resolve => {
              connection.query( studentquery + room.roomID, function ( error, results, fields ) {
                results.forEach( student => {
                  let studentdetail = {
                    name: student.name,
                    id: student.studentID,
                    gender: student.gender
                  }
                  roomdetail.student.push( studentdetail );
                } )
                resolve( y )
              } )
            } )
          }
          async function studentcompleted () {
            await studentselection();
            renderdata.room.push( roomdetail );
          }
          studentcompleted();
        } )
        console.log(renderdata);
        resolve(x)
      } );
    } )
  }
  async function roomcompleted () {
    await roomselection();
    res.render( 'index', renderdata );
  }
  roomcompleted();
} );

module.exports = router;
