var express = require('express');
var router = express.Router();
var session = require( 'express-session' );
var sql = require('mysql');
var connection = sql.createConnection({
	host: 'localhost',
	user: 'dms',
	password: '1234',
	database: 'dormitory'
});
connection.connect();
router.use( session( {
	secret: '2015211911',
	cookie: {}
} ) );

router.get( '/', function ( req, res, next ) {
	res.redirect( '/' );
});

router.get('/repair', function (req, res, next) {
	res.render('managing', {
		title: "宿舍管理系统-维修申请",
		repair: 1,
		repairdetail: [{
			id: 1,
			name: "李四",
			room: "606",
			item: "日光灯",
			reason: "灯管烧坏了"
		}]
	});
});
router.get('/visit', function (req, res, next) {
	res.render('managing', {
		title: "宿舍管理系统-访客申请",
		visitor: 1,
		visitordetail: [{
			id: 1,
			name: "张三",
			arrive: "2018/01/01 12:00",
			leave: "2018/01/01 13:00",
			contact: "13012341234",
			reason: "看望学生"
		}]
	});
});


module.exports = router;